document.addEventListener('DOMContentLoaded', function () {
    const toggleButton = document.querySelector('.togglebtn');
    const navLinks = document.querySelector('.navlinks');

    toggleButton.addEventListener('click', function () {
        navLinks.classList.toggle('open');
        this.classList.toggle('click');
    });

    new Typed(".input", {
        strings: ["","Fullstack Developer", "Web Developer", "Python Developer"],
        typeSpeed: 70,
        backSpeed: 30,
        loop: true,
        loopCount: Infinity,
        backDelay: 1500,
        startDelay: 500,
    });
});
